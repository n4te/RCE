# encoding: ASCII-8BIT
#!/usr/bin/env ruby
require 'metasm'
include Metasm

# produce handler’s x86 code
sc = Metasm::Shellcode.assemble(Metasm::Ia32.new, <<EOS)
entry:
    mov ecx, 1
    shl ecx, 0xA
    add edx, 0xBADC0FFE
    mov eax, 0x100000
    lea eax, [ecx+eax]
    add ecx, 0xBADC0FFE
    jmp eax
EOS

# disassemble handler code
dasm = sc.init_disassembler
dasm.disassemble(0)

# get basic block
bb = dasm.block_at(0)
puts "[+] basic bloc:"
puts bb.list

target = dasm.get_xrefs_x(bb.list.last).first
puts "\n[+] backtrack jmp target: #{target}\n\n"

# backtrace
values = dasm.backtrace(target, bb.list.last.address,
    {:log => bt_log = [], :include_start => true})

bt_log.each{|entry|
    case type = entry.first
    when :start
        entry, expr, addr = entry
        puts "[start] backtacking expr #{expr} from 0x#{addr.to_s(16)}"

    when :di
        entry, to, from, instr = entry
        puts "[update] instr #{instr},\n  -> update expr from #{from} to#{to}\n"

    when :found
       entry, final = entry
       puts "[found] possible value: #{final.first}\n"

    when :up
        entry, to, from, addr_down, addr_up = entry
        puts "[up] addr 0x#{addr_down.to_s(16)} -> 0x#{addr_up.to_s(16)}"
    end
}

# DecodedInstruction object is the 3rd item of :id entry
slice = bt_log.select{|e| e.first==:di}.map{|e| e[3]}.reverse
puts "\n[+] slice:"
puts slice
