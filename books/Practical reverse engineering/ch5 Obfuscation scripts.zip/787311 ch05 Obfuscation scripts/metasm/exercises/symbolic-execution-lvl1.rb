# encoding: ASCII-8BIT
#!/usr/bin/env ruby

require 'metasm'
include Metasm

$SPAWN_GUI = false
CODE_BASE_ADDR = 0x10000000
HTABLE_BASE_ADDR = 0x18000000
NATIVE_REGS = [:eax, :edx, :ecx, :ebx, :esp, :ebp, :esi, :edi]

def display(bd)
  bd.each{|key,value| puts "  #{Expression[key]} => #{Expression[value]}"}
end

# produce handler's x86 code
sc = Shellcode.assemble(Ia32.new, <<EOS)
mov eax, [edi+0x1C]
mov edx, [edi+0x14]
xor eax, edx
mov [edi+0x1c], eax
add ebp, 0x13C
jmp [#{HTABLE_BASE_ADDR}+ebp*4]
EOS

handler = sc.encode_string

# add a code section
dasm = sc.init_disassembler
dasm.add_section(EncodedData.new(handler), CODE_BASE_ADDR)

# disassemble handler code
dasm.disassemble_fast_deep(CODE_BASE_ADDR)

if $SPAWN_GUI
  Gui::DasmWindow.new("metasm - symbolic-execution-lvl1", dasm, [CODE_BASE_ADDR])
  dasm.load_plugin('hl_opcode') # hilight jmp/call instrs
  dasm.gui.focus_addr(dasm.gui.curaddr, :graph) # start in graph mode
  Gui.main
end

=begin

Question 1:

Compute handler's semantics

Metasm, hints
- Disassembler class: code_binding method

=end

# compute handler's semantics

puts "\n=== Question 1 ==="


=begin

Question 2:

During vm bootstrap, vm's context (which is referenced using EDI) is initialized using:
  pushad
  mov edi, esp

The vm's dispatcher uses EBP to store next handler's number

Find symbolic mapping between vm's context and asm code

Metasm hints
- Indirection class: Indirection[Expression, size, origin]
- Expression class: Expression[e1, (op), (e2)],  bind and reduce_rec mesthods

=end

puts "\n=== Question 2 ==="


=begin

Question 3:

Vm's context before handler's execution is:
context = {
    :nhandler => 0x84,
    virt_eax => 0xffeeffee,
    virt_ecx => 0,
    virt_edx => 0x41414141,
    virt_ebx => 1,
    :virt_edi => :virt_edi,
    :virt_esi => :virt_esi,
}

Compute the result of handler's execution

=end

puts "\n=== Question 3 ==="

