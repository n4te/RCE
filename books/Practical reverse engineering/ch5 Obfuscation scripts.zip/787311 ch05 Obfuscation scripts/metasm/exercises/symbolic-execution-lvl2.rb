# encoding: ASCII-8BIT
#!/usr/bin/env ruby

require 'metasm'
include Metasm

$SPAWN_GUI = false
CODE_BASE_ADDR = 0x10000000
HTABLE_BASE_ADDR = 0x18000000
DATA_BASE_ADDR = 0x1a000000
INJECT_MAX_ITER = 0x20
NATIVE_REGS = [:eax, :edx, :ecx, :ebx, :esp, :ebp, :esi, :edi]

def display(bd)
    bd.each{|key,value| puts "  #{Expression[key]} => #{Expression[value]}"}
end

# produce handler's x86 code
sc = Metasm::Shellcode.assemble(Metasm::Ia32.new, <<EOS)
lodsd
mov ecx, eax
xor ecx, ebp
movzx eax, cl
push eax
mov eax, [edi+eax]

movzx edx, ch
mov edx, [edi+edx]
xor eax, edx

pop edx
mov [edi+edx], eax

lodsd
xor ebp, 0x35ef6a14
xor eax, ebp
jmp [#{HTABLE_BASE_ADDR}+eax*4]
EOS

handler = sc.encode_string

# data section hex
data_section_hex = "\xA3\xCB\xDB\x5F\x60\xBD\x34\x6A"

# add a code section
dasm = sc.init_disassembler
dasm.add_section(EncodedData.new(handler), CODE_BASE_ADDR)

# add a data section
dasm.add_section(EncodedData.new(data_section_hex), DATA_BASE_ADDR)

# disassemble handler code
dasm.disassemble_fast_deep(CODE_BASE_ADDR)

if $SPAWN_GUI
    Gui::DasmWindow.new("metasm - symbolic-execution-lvl2", dasm, [CODE_BASE_ADDR])
    dasm.load_plugin('hl_opcode') # hilight jmp/call instrs
    dasm.gui.focus_addr(dasm.gui.curaddr, :graph) # start in graph mode
    Gui.main
end

=begin

Question 1:

Previous sample was...a sample. The code does not work in real life.

Compute the handler's semantics.

=end

# compute handler's semantics

puts "\n=== Question 1 ==="


=begin

Question 2:

For the first vm's call, the context is initialized as follow:
  pushad
  mov edi, esp

The vm uses a turning key stored in ebp register.

Recover mapping between vm's context and code semantics.

=end

puts "\n=== Question 2 ==="


=begin

Question 3:

The vm's context before handler's execution is the following:
context = {
  :nhandler => 0x84,
  :vmkey => 0x5fdbd7b7,
  virt_ecx => 0,
  virt_edx => 0x41414141,
  virt_ebx => 1,
  :virt_edi => :virt_edi,
  :virt_esi => DATA_BASE_ADDR,
}

Compute the result of handler's execution.

Problems:
  - How to solve access to program's data ?

=end

puts "\n=== Question 3 ==="


=begin

Question 4 (bonus):

How could we try to regenerate some native code ?

=end

puts "\n=== Question 4 ==="
