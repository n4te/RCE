# encoding: ASCII-8BIT
#!/usr/bin/env ruby

require 'metasm'
include Metasm

$SPAWN_GUI = false
CODE_BASE_ADDR = 0x100000
HTABLE_BASE_ADDR = 0x180000
DATA_BASE_ADDR = 0x1a0000
INJECT_MAX_ITER = 0x20
NATIVE_REGS = [:eax, :edx, :ecx, :ebx, :esp, :ebp, :esi, :edi]

def display(bd)
    bd.each{|key,value| puts "  #{Expression[key]} => #{Expression[value]}"}
end

# produce handler's x86 code
sc = Metasm::Shellcode.assemble(Metasm::Ia32.new, <<EOS)
lodsd
mov ecx, eax
xor ecx, ebp
movzx eax, cl
push eax
mov eax, [edi+eax]

movzx edx, ch
mov edx, [edi+edx]
xor eax, edx

pop edx
mov [edi+edx], eax

lodsd
xor ebp, 0x35ef6a14
xor eax, ebp
jmp [#{HTABLE_BASE_ADDR}+eax*4]
EOS

handler = sc.encode_string

# data section hex
data_section_hex = "\xA3\xCB\xDB\x5F\x60\xBD\x34\x6A"

# add a code section
dasm = sc.init_disassembler
dasm.add_section(EncodedData.new(handler), CODE_BASE_ADDR)

# add a data section
dasm.add_section(EncodedData.new(data_section_hex), DATA_BASE_ADDR)

# disassemble handler code
dasm.disassemble_fast_deep(CODE_BASE_ADDR)

if $SPAWN_GUI
    Gui::DasmWindow.new("metasm - symbolic-execution-lvl2", dasm, [CODE_BASE_ADDR])
    dasm.load_plugin('hl_opcode') # hilight jmp/call instrs
    dasm.gui.focus_addr(dasm.gui.curaddr, :graph) # start in graph mode
    Gui.main
end

=begin

Question 1:

Previous sample was...a sample. The code does not work in real life.

Compute the handler's semantics.

=end

# compute handler's semantics

puts "\n=== Question 1 ==="

basic_block = dasm.di_at(CODE_BASE_ADDR).block
start_addr = basic_block.list.first.address
end_addr = basic_block.list.last.address

puts "\n[+] computing semantics for handler at 0x#{start_addr.to_s(16)}, end address #{end_addr.to_s(16)}"
binding = dasm.code_binding(start_addr, end_addr)
display(binding)

=begin

Question 2:

For the first vm's call, the context is initialized as follow:
  pushad
  mov edi, esp

The vm uses a turning key stored in ebp register.

Recover mapping between vm's context and code semantics.

=end

puts "\n=== Question 2 ==="

vm_symbolism = {
    :eax => :nhandler,
    :ebp => :vmkey,
    :esi => :bytecode_ptr,
    Indirection[[:edi], 4, nil] => :virt_edi,
    Indirection[[:edi, :+, 4], 4, nil] => :virt_esi,
    Indirection[[:edi, :+, 8], 4, nil] => :virt_ebp,
    Indirection[[:edi, :+, 0x10], 4, nil] => :virt_ebx,
    Indirection[[:edi, :+, 0x14], 4, nil] => :virt_edx,
    Indirection[[:edi, :+, 0x18], 4, nil] => :virt_ecx,
    Indirection[[:edi, :+, 0x1c], 4, nil] => :virt_eax,
}

def inject(binding, symbolism)
    return binding if not symbolism or symbolism.empty?
    new_binding = {}
    binding.each{|k, val|
        k = Expression[k].bind(symbolism)
        val = Expression[val].bind(symbolism)
        new_binding[Expression[k].reduce_rec] = Expression[val].reduce_rec
    }
    new_binding
end

puts "\n[+] symbolic binding"
symbolic_binding = inject(binding, vm_symbolism)
symbolic_binding.reject!{|k,v| NATIVE_REGS.include? k}
display(symbolic_binding)

=begin

Question 3:

The vm's context before handler's execution is the following:
context = {
  :nhandler => 0x84,
  :vmkey => 0x5fdbd7b7,
  virt_ecx => 0,
  virt_edx => 0x41414141,
  virt_ebx => 1,
  :virt_edi => :virt_edi,
  :virt_esi => DATA_BASE_ADDR,
}

Compute the result of handler's execution.

Problems:
  - How to solve access to program's data ?

=end

puts "\n=== Question 3 ==="

context = {
    :nhandler => 0x84,
    :vmkey => 0x5fdbd7b7,
    :bytecode_ptr => DATA_BASE_ADDR,
    :virt_eax => 0xffeeffee,
    :virt_ecx => 0,
    :virt_edx => 0x41414141,
    :virt_ebx => 1,
    :virt_edi => :virt_edi,
}

puts "\n[+] original context"
display(context)
$dasm = dasm

def solve_ind_partial(i, mode = :r)
    case i
    when Indirection
        # do not solve final Indirection for keys (mode write)
        return i if (mode == :w) and (i.complexity <= 2)

        # solve indirection target
        mem_addr = solve_ind_partial(i.target)

        # check if memory address is within binary data
        if s = $dasm.get_section_at(mem_addr)
          # read memory
          puts "     [+] solved memory read at 0x#{mem_addr.to_s(16)}, size #{i.len}"
          value = s[0].decode_imm("a#{i.len*8}".to_sym, $dasm.cpu.endianness)
          puts "     [+] value #{Expression[value]}"
          return value
        end

        Indirection[mem_addr, i.len, nil]

    when Expression
        tmp = i.bind(i.expr_indirections.inject({}) {|b, e|
            b.update e => Expression[solve_ind_partial(e)] }).reduce
        (tmp.kind_of? Integer) ? Expression[tmp, :&, 0xffff_ffff].reduce_rec : tmp

    when Integer; Expression[i, :&, 0xffff_ffff].reduce_rec
    when Symbol; i
    else Expression::Unknown; raise i.inspect
    end
end

def sym_exec_v2(context, binding, vm_symbolism)

    # iterative solver
    injector = lambda{|v, i, mode|
    next v if (v.kind_of? Symbol) and mode == :w
    next v if v.kind_of? Integer

    oldv = v
    oldoldv = oldv

    iter = 0
    while true
        iter += 1

        # if key, do not solve final memory indirection
        break if (mode == :w) and v.kind_of? Indirection and Expression[v.target].reduce_rec.kind_of? Integer

        v = Expression[v].bind(vm_symbolism).reduce_rec
        break if (v.kind_of? Symbol) and mode == :w

        v = Expression[v].bind(i).reduce_rec
        break if (v.kind_of? Symbol) and mode == :w

        v = Expression[solve_ind_partial(Expression[v], mode)].reduce_rec

        raise "[-] I feel a disturbance in the force, infinite loop" if (oldoldv == v and not oldoldv == oldv) or (iter > INJECT_MAX_ITER)
        break if v == oldv
        oldoldv = oldv
        oldv = v
        end
        v
    }

    # solve advanced binding using injector
    puts "\n[+] binding solver"
    full_bd = {}
    binding.each{|key, val|
        puts "\n  [+] key: #{Expression[key]}"
        full_key = (key.kind_of? Symbol) ? key : injector[key, context.reject{|k,v| k==key}, :w]
        puts "     => solved key: #{Expression[full_key]}"

        puts "\n  [+] value: #{Expression[val]}"
        full_val = injector[val, context.reject{|k,v| v==val}, :r]
        puts "     => solved key: #{Expression[full_val]}"

        full_bd[full_key] = full_val
    }

    # filter binding (depends on the vm's architecture)
    full_bd.reject!{|k,v| not k.kind_of? Symbol}
end

solved_binding =  sym_exec_v2(context, symbolic_binding, vm_symbolism)

puts "\n[+] solved binding"
display(solved_binding)

updated_context = context.update(solved_binding)

puts "\n[+] updated context"
display(updated_context)

=begin

Question 4 (bonus):

How could we try to regenerate some native code ?

=end

puts "\n=== Question 4 ==="

# hint, we're using a purely symbolic context here:
symbolic_context = {
    :nhandler => 0x84,
    :vmkey => 0x5fdbd7b7,
    :bytecode_ptr => DATA_BASE_ADDR,
    :virt_eax => :virt_eax,
    :virt_ecx => :virt_ecx,
    :virt_edx => :virt_edx,
    :virt_ebx => :virt_ebx,
    :virt_edi => :virt_edi
}

puts "\n[+] solved context"
display(symbolic_context)

solved_symolic_binding = sym_exec_v2(symbolic_context, symbolic_binding, vm_symbolism)

puts "\n[+] solved binding"
display(solved_symolic_binding)

